package com.eshoppingzone.produt.exception;

public class ProductCategoryNotFoundException extends RuntimeException {

	public ProductCategoryNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductCategoryNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductCategoryNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

		

}
