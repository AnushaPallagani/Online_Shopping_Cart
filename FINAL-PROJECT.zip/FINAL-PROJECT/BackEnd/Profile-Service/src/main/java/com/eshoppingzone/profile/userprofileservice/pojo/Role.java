package com.eshoppingzone.profile.userprofileservice.pojo;

public interface Role {
	
	static final String customer="customer";
	static final String merchant="merchant";
	static final String deliveryAgent="delivery Agent";


	

}
