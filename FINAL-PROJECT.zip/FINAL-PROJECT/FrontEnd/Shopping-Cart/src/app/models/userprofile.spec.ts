import { Userprofile } from './userprofile';

describe('Userprofile', () => {
  it('should create an instance', () => {
    expect(new Userprofile()).toBeTruthy();
  });
});
